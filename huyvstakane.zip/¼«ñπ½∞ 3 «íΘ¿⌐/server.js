const express = require('express');
const fs = require('fs').promises; // Для работы с файлами асинхронно
const cors = require('cors'); // Для разрешения запросов с разных доменов
const path = require('path');

const app = express();
const PORT = 3000;
const DB_FILE = path.join(__dirname, 'db.json'); // Путь к вашему файлу db.json

app.use(cors()); // Разрешить запросы от вашего HTML
app.use(express.json()); // Для парсинга JSON в теле запроса

// Роут для получения пользователей
app.get('/api/users', async (req, res) => {
    try {
        const data = await fs.readFile(DB_FILE, 'utf8');
        const db = JSON.parse(data);
        res.json(db.users);
    } catch (error) {
        console.error('Error reading db.json:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Роут для обновления всех пользователей (например, после изменения)
app.post('/api/users', async (req, res) => {
    try {
        const updatedUsers = req.body; // Получаем обновленный массив пользователей
        const db = { users: updatedUsers }; // Создаем объект с ключом "users"
        await fs.writeFile(DB_FILE, JSON.stringify(db, null, 2), 'utf8'); // Записываем в файл
        res.status(200).json({ message: 'Users updated successfully' });
    } catch (error) {
        console.error('Error writing to db.json:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Обслуживание статических файлов (HTML, CSS, JS)
app.use(express.static(__dirname));

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});