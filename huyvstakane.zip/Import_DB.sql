﻿CREATE TABLE `Category` (
    `id_category` INT AUTO_INCREMENT ,
    `name` VARCHAR(50)  NOT NULL ,
    PRIMARY KEY (
        `id_category`
    )
);

INSERT IGNORE INTO `Category` (`name`) VALUES ('На каждый день');
INSERT IGNORE INTO `Category` (`name`) VALUES ('Праздник');
INSERT IGNORE INTO `Category` (`name`) VALUES ('Груз и шаттл');
INSERT IGNORE INTO `Category` (`name`) VALUES ('Молния');
INSERT IGNORE INTO `Category` (`name`) VALUES ('Жара');

CREATE TABLE `Vehicle` (
    `id_vehicle` INT NOT NULL AUTO_INCREMENT, -- Добавлено: первичный ключ для Vehicle
    `category_id` INT,
    `brand` VARCHAR (20),
    `license_plate` VARCHAR(20),
    PRIMARY KEY (
        `id_vehicle`
    )
);

INSERT INTO `Vehicle` (`category_id`, `brand`, `license_plate`) VALUES
((SELECT id_category FROM Category WHERE name = 'На каждый день'), 'Geely Coolray Flagship', 'м324ст797'),
((SELECT id_category FROM Category WHERE name = 'На каждый день'), 'Geely Coolray Flagship', 'е434ка797'),
((SELECT id_category FROM Category WHERE name = 'На каждый день'), 'Geely Coolray Flagship', 'у831ое77'),
((SELECT id_category FROM Category WHERE name = 'На каждый день'), 'Renault Duster', 'с452оо77'),
((SELECT id_category FROM Category WHERE name = 'На каждый день'), 'Renault Duster', 'м674то97'),
((SELECT id_category FROM Category WHERE name = 'На каждый день'), 'Renault Duster', 'е592оу777'),
((SELECT id_category FROM Category WHERE name = 'На каждый день'), 'Renault Duster', 'о553вс797'),
((SELECT id_category FROM Category WHERE name = 'На каждый день'), 'Volkswagen Polo 6', 'о444ту197'),
((SELECT id_category FROM Category WHERE name = 'На каждый день'), 'Volkswagen Polo 6', 'с591ут97'),
((SELECT id_category FROM Category WHERE name = 'На каждый день'), 'Volkswagen Polo 6', 'в667см97'),
((SELECT id_category FROM Category WHERE name = 'На каждый день'), 'Volkswagen Polo 6', 'в569оо777'),
((SELECT id_category FROM Category WHERE name = 'На каждый день'), 'Volkswagen Polo 6', 'с231оо797'),
((SELECT id_category FROM Category WHERE name = 'На каждый день'), 'Volkswagen Polo 6', 'в583ее77'),
((SELECT id_category FROM Category WHERE name = 'Праздник'), 'Mercedes E200', 'о454вс77'),
((SELECT id_category FROM Category WHERE name = 'Праздник'), 'Mercedes E200', 'е982то97'),
((SELECT id_category FROM Category WHERE name = 'Праздник'), 'Mercedes E200', 'е337ео777'),
((SELECT id_category FROM Category WHERE name = 'Праздник'), 'Mercedes C180', 'о123оу777'),
((SELECT id_category FROM Category WHERE name = 'Праздник'), 'Mercedes C180', 'о093оо97'),
((SELECT id_category FROM Category WHERE name = 'Праздник'), 'Audi A6', 'е772ое777'),
((SELECT id_category FROM Category WHERE name = 'Груз и шаттл'), 'Ford Transit', 'о438вм97'),
((SELECT id_category FROM Category WHERE name = 'Груз и шаттл'), 'Ford Transit', 'о127ум97'),
((SELECT id_category FROM Category WHERE name = 'Груз и шаттл'), 'Peugeot Expert', 'в673со77'),
((SELECT id_category FROM Category WHERE name = 'Молния'), 'Электрокар Nissan Leaf', 'е654аа777'),
((SELECT id_category FROM Category WHERE name = 'Молния'), 'Электрокар Nissan Leaf', 'а676ут797'),
((SELECT id_category FROM Category WHERE name = 'Жара'), 'Jeep Sahara', 'т444от777');

CREATE TABLE `Client` (
    `id_client` INT  NOT NULL ,
    `first_name` VARCHAR(50)  NOT NULL ,
    `last_name` VARCHAR(50)  NOT NULL ,
    `phone` VARCHAR(20)  NOT NULL ,
    `email` VARCHAR(100)  NOT NULL ,
    `license_number` VARCHAR(20)  NOT NULL ,
    PRIMARY KEY (
        `id_client`
    )
);

CREATE TABLE `Staff` (
    `id_staff` INT  NOT NULL ,
    `first_name` VARCHAR(50)  NOT NULL ,
    `last_name` VARCHAR(50)  NOT NULL ,
    `role` VARCHAR(50)  NOT NULL ,
    PRIMARY KEY (
        `id_staff`
    )
);

CREATE TABLE `Booking` (
    `id_booking` INT  NOT NULL ,
    `vehicle_id` INT  NOT NULL ,
    `client_id` INT  NOT NULL ,
    `admin_id` INT  NOT NULL ,
    `start_date` DATETIME  NOT NULL ,
    `end_date` DATETIME  NOT NULL ,
    `payment_status` VARCHAR(20)  NOT NULL ,
    PRIMARY KEY (
        `id_booking`
    )
);

CREATE TABLE `Maintenance` (
    `id_maintenance` INT  NOT NULL ,
    `vehicle_id` INT  NOT NULL ,
    `staff_id` INT  NOT NULL ,
    `start_date` DATETIME  NOT NULL ,
    `end_date` DATETIME  NOT NULL ,
    `status` VARCHAR(20)  NOT NULL ,
    PRIMARY KEY (
        `id_maintenance`
    )
);

ALTER TABLE `Vehicle` ADD CONSTRAINT `fk_Vehicle_category_id` FOREIGN KEY(`category_id`)
REFERENCES `Category` (`id_category`);

ALTER TABLE `Booking` ADD CONSTRAINT `fk_Booking_vehicle_id` FOREIGN KEY(`vehicle_id`)
REFERENCES `Vehicle` (`id_vehicle`);

ALTER TABLE `Booking` ADD CONSTRAINT `fk_Booking_client_id` FOREIGN KEY(`client_id`)
REFERENCES `Client` (`id_client`);

ALTER TABLE `Booking` ADD CONSTRAINT `fk_Booking_admin_id` FOREIGN KEY(`admin_id`)
REFERENCES `Staff` (`id_staff`);

ALTER TABLE `Maintenance` ADD CONSTRAINT `fk_Maintenance_vehicle_id` FOREIGN KEY(`vehicle_id`)
REFERENCES `Vehicle` (`id_vehicle`);

ALTER TABLE `Maintenance` ADD CONSTRAINT `fk_Maintenance_staff_id` FOREIGN KEY(`staff_id`)
REFERENCES `Staff` (`id_staff`);