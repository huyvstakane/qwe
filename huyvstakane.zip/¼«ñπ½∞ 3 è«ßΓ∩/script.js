document.addEventListener('DOMContentLoaded', () => {
    // --- UI Elements ---
    const loginSection = document.getElementById('login-section');
    const registerSection = document.getElementById('register-section');
    const forgotPasswordSection = document.getElementById('forgot-password-section');
    const firstLoginChangePasswordSection = document.getElementById('first-login-change-password-section'); // NEW
    const profileChangePasswordSection = document.getElementById('profile-change-password-section'); // NEW
    const dashboardSection = document.getElementById('dashboard-section');

    const loginForm = document.getElementById('login-form');
    const loginUsernameInput = document.getElementById('login-username');
    const loginPasswordInput = document.getElementById('login-password');
    const loginMessage = document.getElementById('login-message');
    const showRegisterButton = document.getElementById('show-register-button');
    const showForgotPasswordButton = document.getElementById('show-forgot-password-button');

    const registerForm = document.getElementById('register-form');
    const registerUsernameInput = document.getElementById('register-username');
    const registerPasswordInput = document.getElementById('register-password');
    const confirmRegisterPasswordInput = document.getElementById('confirm-register-password');
    const registerRoleSelect = document.getElementById('register-role');
    const registerMessage = document.getElementById('register-message');
    const backToLoginFromRegister = document.getElementById('back-to-login-from-register');

    const forgotPasswordForm = document.getElementById('forgot-password-form');
    const forgotUsernameInput = document.getElementById('forgot-username');
    const forgotPasswordMessage = document.getElementById('forgot-password-message');
    const backToLoginFromForgot = document.getElementById('back-to-login-from-forgot');

    const firstLoginChangePasswordForm = document.getElementById('first-login-change-password-form'); // NEW
    const firstLoginNewPasswordInput = document.getElementById('first-login-new-password'); // NEW
    const firstLoginConfirmNewPasswordInput = document.getElementById('first-login-confirm-new-password'); // NEW
    const firstLoginPasswordChangeMessage = document.getElementById('first-login-password-change-message'); // NEW

    const profileChangePasswordForm = document.getElementById('profile-change-password-form'); // NEW
    const profileOldPasswordInput = document.getElementById('profile-old-password'); // NEW
    const profileNewPasswordInput = document.getElementById('profile-new-password'); // NEW
    const profileConfirmNewPasswordInput = document.getElementById('profile-confirm-new-password'); // NEW
    const profilePasswordChangeMessage = document.getElementById('profile-password-change-message'); // NEW
    const backToDashboardFromProfileChange = document.getElementById('back-to-dashboard-from-profile-change'); // NEW

    const dashboardTitle = document.getElementById('dashboard-title');
    const welcomeMessage = document.getElementById('welcome-message');
    const logoutButton = document.getElementById('logout-button');
    const showProfileChangePasswordButton = document.getElementById('show-profile-change-password-button'); // NEW
    const adminPanel = document.getElementById('admin-panel');
    const adminAddUserForm = document.getElementById('admin-add-user-form');
    const adminNewUserLoginInput = document.getElementById('admin-new-user-login');
    const adminNewUserPasswordInput = document.getElementById('admin-new-user-password');
    const adminNewUserRoleSelect = document.getElementById('admin-new-user-role');
    const adminAddUserMessage = document.getElementById('admin-add-user-message');
    const userList = document.getElementById('user-list');

    // --- State Variables ---
    let currentUser = null;
    let users = [];

    // --- Utility Functions for "Mock DB" (localStorage) ---
    async function loadUsers() {
        try {
            const response = await fetch('db.json');
            const data = await response.json();
            users = data.users;
            console.log('Users loaded from db.json:', users);
            saveUsersToLocalStorage(); // Initial save to localStorage
        } catch (error) {
            console.error('Error loading db.json:', error);
            displayMessage(loginMessage, 'Ошибка загрузки данных. Пожалуйста, попробуйте позже.', 'error');
        }
    }

    function saveUsersToLocalStorage() {
        localStorage.setItem('users_mock_db', JSON.stringify(users));
        console.log('Users saved to localStorage.');
    }

    async function initializeUsers() {
        const storedUsers = localStorage.getItem('users_mock_db');
        if (storedUsers) {
            users = JSON.parse(storedUsers);
            console.log('Users loaded from localStorage:', users);
        } else {
            await loadUsers();
        }
    }

    // --- UI Management ---
    function showSection(sectionId) {
        // Hide all sections
        loginSection.classList.add('hidden');
        registerSection.classList.add('hidden');
        forgotPasswordSection.classList.add('hidden');
        firstLoginChangePasswordSection.classList.add('hidden'); // NEW
        profileChangePasswordSection.classList.add('hidden');    // NEW
        dashboardSection.classList.add('hidden');

        // Show the requested section and clear relevant forms
        if (sectionId === 'login') {
            loginSection.classList.remove('hidden');
            loginMessage.textContent = '';
            loginForm.reset();
        } else if (sectionId === 'register') {
            registerSection.classList.remove('hidden');
            registerMessage.textContent = '';
            registerForm.reset();
        } else if (sectionId === 'forgotPassword') {
            forgotPasswordSection.classList.remove('hidden');
            forgotPasswordMessage.textContent = '';
            forgotPasswordForm.reset();
        } else if (sectionId === 'firstLoginChangePassword') { // NEW
            firstLoginChangePasswordSection.classList.remove('hidden');
            firstLoginPasswordChangeMessage.textContent = '';
            firstLoginChangePasswordForm.reset();
        } else if (sectionId === 'profileChangePassword') { // NEW
            profileChangePasswordSection.classList.remove('hidden');
            profilePasswordChangeMessage.textContent = '';
            profileChangePasswordForm.reset();
        } else if (sectionId === 'dashboard') {
            dashboardSection.classList.remove('hidden');
            updateDashboard();
        }
    }

    function displayMessage(element, message, type) {
        element.textContent = message;
        element.className = `message ${type}`;
        setTimeout(() => {
            element.textContent = '';
            element.className = 'message';
        }, 5000);
    }

    // --- Login Logic ---
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const username = loginUsernameInput.value;
        const password = loginPasswordInput.value;
        loginMessage.textContent = '';

        const user = users.find(u => u.login === username);

        if (!user) {
            handleFailedLogin(null);
            displayMessage(loginMessage, 'Неверный логин или пароль.', 'error');
            return;
        }

        // Check for inactivity block
        const oneMonthAgo = new Date();
        oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
        if (user.lastLogin && new Date(user.lastLogin) < oneMonthAgo) {
            user.isBlocked = true;
            saveUsersToLocalStorage();
            displayMessage(loginMessage, 'Ваша учетная запись заблокирована из-за длительного отсутствия активности. Обратитесь к администратору.', 'error');
            return;
        }

        if (user.isBlocked) {
            displayMessage(loginMessage, 'Ваша учетная запись заблокирована. Обратитесь к администратору.', 'error');
            return;
        }

        if (user.password === password) {
            // Successful login
            user.failedAttempts = 0;
            user.lastLogin = new Date().toISOString();
            saveUsersToLocalStorage();

            currentUser = user;
            displayMessage(loginMessage, 'Вы успешно авторизовались!', 'success');
            loginUsernameInput.value = '';
            loginPasswordInput.value = '';

            if (currentUser.firstLogin) {
                showSection('firstLoginChangePassword'); // MANDATORY change for first login
            } else {
                showSection('dashboard');
            }
        } else {
            handleFailedLogin(user);
            displayMessage(loginMessage, 'Неверный логин или пароль.', 'error');
        }
    });

    function handleFailedLogin(user) {
        if (user) {
            user.failedAttempts = (user.failedAttempts || 0) + 1;
            if (user.failedAttempts >= 3) {
                user.isBlocked = true;
                displayMessage(loginMessage, 'Ваша учетная запись заблокирована из-за 3х неудачных попыток входа.', 'error');
            }
            saveUsersToLocalStorage();
        }
    }

    // --- Registration Logic ---
    showRegisterButton.addEventListener('click', () => showSection('register'));
    backToLoginFromRegister.addEventListener('click', () => showSection('login'));

    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const username = registerUsernameInput.value;
        const password = registerPasswordInput.value;
        const confirmPassword = confirmRegisterPasswordInput.value;
        const role = registerRoleSelect.value;
        registerMessage.textContent = '';

        if (!username || !password || !confirmPassword) {
            displayMessage(registerMessage, 'Все поля обязательны для заполнения.', 'error');
            return;
        }

        if (password !== confirmPassword) {
            displayMessage(registerMessage, 'Пароли не совпадают.', 'error');
            return;
        }

        if (users.some(u => u.login.toLowerCase() === username.toLowerCase())) {
            displayMessage(registerMessage, 'Пользователь с таким логином уже существует.', 'error');
            return;
        }

        const newId = users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1;
        const newUser = {
            id: newId,
            login: username,
            password: password, // In real app: HASH THIS!
            role: role,
            lastLogin: null,
            failedAttempts: 0,
            isBlocked: false,
            firstLogin: true // New users always change password on first login
        };

        users.push(newUser);
        saveUsersToLocalStorage();
        displayMessage(registerMessage, 'Регистрация успешна! Теперь вы можете войти (потребуется смена пароля).', 'success');
        registerForm.reset();
        setTimeout(() => showSection('login'), 3000);
    });

    // --- Forgot Password Logic ---
    showForgotPasswordButton.addEventListener('click', () => showSection('forgotPassword'));
    backToLoginFromForgot.addEventListener('click', () => showSection('login'));

    forgotPasswordForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const username = forgotUsernameInput.value;
        forgotPasswordMessage.textContent = '';

        const user = users.find(u => u.login.toLowerCase() === username.toLowerCase());

        if (!user) {
            displayMessage(forgotPasswordMessage, 'Пользователь с таким логином не найден.', 'error');
            return;
        }

        if (user.isBlocked) {
            displayMessage(forgotPasswordMessage, 'Ваша учетная запись заблокирована. Обратитесь к администратору.', 'error');
            return;
        }

        // Simulating password reset by setting firstLogin to true and redirecting to mandatory change
        // In a real app, this would involve sending an email with a reset link.
        user.firstLogin = true; // Force password change
        saveUsersToLocalStorage();
        currentUser = user; // Set current user for firstLoginChangePasswordSection
        displayMessage(forgotPasswordMessage, 'Пожалуйста, установите новый пароль.', 'success');
        setTimeout(() => showSection('firstLoginChangePassword'), 2000); // Redirect to mandatory change
    });

    // --- First Login Mandatory Change Password Logic ---
    firstLoginChangePasswordForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const newPassword = firstLoginNewPasswordInput.value;
        const confirmNewPassword = firstLoginConfirmNewPasswordInput.value;
        firstLoginPasswordChangeMessage.textContent = '';

        if (!newPassword || !confirmNewPassword) {
            displayMessage(firstLoginPasswordChangeMessage, 'Все поля обязательны для заполнения.', 'error');
            return;
        }

        if (newPassword !== confirmNewPassword) {
            displayMessage(firstLoginPasswordChangeMessage, 'Новый пароль и подтверждение не совпадают.', 'error');
            return;
        }

        // Assuming this is always a temporary password scenario, no need to check old password
        // If the user's previous password was known and they just got reset,
        // you might add a check here for `oldPasswordInput.value === currentUser.password`
        // if you had a separate field for it.

        currentUser.password = newPassword;
        currentUser.firstLogin = false; // Password changed, no longer first login
        saveUsersToLocalStorage();

        displayMessage(firstLoginPasswordChangeMessage, 'Пароль успешно установлен!', 'success');
        firstLoginChangePasswordForm.reset();
        setTimeout(() => showSection('dashboard'), 2000);
    });

    // --- Profile Change Password Logic ---
    showProfileChangePasswordButton.addEventListener('click', () => showSection('profileChangePassword'));
    backToDashboardFromProfileChange.addEventListener('click', () => showSection('dashboard'));

    profileChangePasswordForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const oldPassword = profileOldPasswordInput.value;
        const newPassword = profileNewPasswordInput.value;
        const confirmNewPassword = profileConfirmNewPasswordInput.value;
        profilePasswordChangeMessage.textContent = '';

        if (!oldPassword || !newPassword || !confirmNewPassword) {
            displayMessage(profilePasswordChangeMessage, 'Все поля обязательны для заполнения.', 'error');
            return;
        }

        if (currentUser.password !== oldPassword) {
            displayMessage(profilePasswordChangeMessage, 'Текущий пароль введен неверно.', 'error');
            return;
        }

        if (newPassword !== confirmNewPassword) {
            displayMessage(profilePasswordChangeMessage, 'Новый пароль и подтверждение не совпадают.', 'error');
            return;
        }

        if (newPassword === oldPassword) {
            displayMessage(profilePasswordChangeMessage, 'Новый пароль не может совпадать с текущим.', 'error');
            return;
        }

        currentUser.password = newPassword;
        saveUsersToLocalStorage();

        displayMessage(profilePasswordChangeMessage, 'Пароль успешно изменен!', 'success');
        profileChangePasswordForm.reset();
        setTimeout(() => showSection('dashboard'), 2000);
    });


    // --- Dashboard Logic (User/Admin) ---
    function updateDashboard() {
        if (currentUser) {
            dashboardTitle.textContent = `Добро пожаловать, ${currentUser.login}!`;
            welcomeMessage.textContent = `Ваша роль: ${currentUser.role}.`;

            if (currentUser.role === 'Администратор') {
                adminPanel.classList.remove('hidden');
                renderUserList();
            } else {
                adminPanel.classList.add('hidden');
            }
        }
    }

    logoutButton.addEventListener('click', () => {
        currentUser = null;
        showSection('login');
    });

    // --- Admin Panel Logic: Add User ---
    adminAddUserForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const newLogin = adminNewUserLoginInput.value;
        const newPassword = adminNewUserPasswordInput.value;
        const newRole = adminNewUserRoleSelect.value;
        adminAddUserMessage.textContent = '';

        if (!newLogin || !newPassword) {
            displayMessage(adminAddUserMessage, 'Логин и пароль обязательны.', 'error');
            return;
        }

        if (users.some(u => u.login.toLowerCase() === newLogin.toLowerCase())) {
            displayMessage(adminAddUserMessage, 'Пользователь с таким логином уже существует.', 'error');
            return;
        }

        const newId = users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1;
        const newUser = {
            id: newId,
            login: newLogin,
            password: newPassword, // In real app: HASH THIS!
            role: newRole,
            lastLogin: null,
            failedAttempts: 0,
            isBlocked: false,
            firstLogin: true // Admins set temporary password, user must change it
        };

        users.push(newUser);
        saveUsersToLocalStorage();
        displayMessage(adminAddUserMessage, `Пользователь "${newLogin}" (${newRole}) успешно добавлен. Он должен сменить пароль при первом входе.`, 'success');

        adminAddUserForm.reset();
        renderUserList();
    });

    // --- Admin Panel Logic: User List Management (Unblock/Delete) ---
    function renderUserList() {
        userList.innerHTML = '';
        users.forEach(user => {
            const listItem = document.createElement('li');
            listItem.innerHTML = `
                <span>Логин: <b>${user.login}</b> | Роль: ${user.role} | ${user.isBlocked ? '<span style="color: red; font-weight: bold;">Заблокирован</span>' : '<span style="color: green;">Активен</span>'}</span>
                <div>
                    ${user.isBlocked ? `<button class="unblock-button" data-id="${user.id}">Разблокировать</button>` : ''}
                    ${user.id !== currentUser.id ? `<button class="delete-button" data-id="${user.id}">Удалить</button>` : '<span style="font-size: 0.8em; color: #6c757d;">(Нельзя удалить себя)</span>'}
                </div>
            `;
            userList.appendChild(listItem);
        });

        document.querySelectorAll('.unblock-button').forEach(button => {
            button.addEventListener('click', (e) => {
                const userId = parseInt(e.target.dataset.id);
                const userToUnblock = users.find(u => u.id === userId);
                if (userToUnblock && userToUnblock.isBlocked) {
                    userToUnblock.isBlocked = false;
                    userToUnblock.failedAttempts = 0;
                    saveUsersToLocalStorage();
                    renderUserList();
                    displayMessage(adminAddUserMessage, `Пользователь "${userToUnblock.login}" разблокирован.`, 'success');
                }
            });
        });

        document.querySelectorAll('.delete-button').forEach(button => {
            button.addEventListener('click', (e) => {
                const userId = parseInt(e.target.dataset.id);
                if (userId === currentUser.id) {
                    displayMessage(adminAddUserMessage, 'Невозможно удалить собственный аккаунт.', 'error');
                    return;
                }
                if (confirm(`Вы уверены, что хотите удалить пользователя с ID ${userId}?`)) {
                    users = users.filter(u => u.id !== userId);
                    saveUsersToLocalStorage();
                    renderUserList();
                    displayMessage(adminAddUserMessage, `Пользователь удален.`, 'success');
                }
            });
        });
    }

    // --- Initialization ---
    initializeUsers().then(() => {
        showSection('login');
        document.getElementById('admin-quick-login-button').addEventListener('click', () => {
    // Проверяем, есть ли администратор в базе
    const adminUser = users.find(u => u.role === 'Администратор');
    
    if (adminUser) {
        // Автоматически логинимся как администратор
        loginUsernameInput.value = adminUser.login;
        loginPasswordInput.value = adminUser.password;
        loginForm.dispatchEvent(new Event('submit'));
    } else {
        // Если администратора нет, создаем временного
        const newAdmin = {
            id: users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1,
            login: 'admin',
            password: 'admin123',
            role: 'Администратор',
            lastLogin: null,
            failedAttempts: 0,
            isBlocked: false,
            firstLogin: true
        };
        users.push(newAdmin);
        saveUsersToLocalStorage();
        
        // Автоматически логинимся как новый администратор
        loginUsernameInput.value = newAdmin.login;
        loginPasswordInput.value = newAdmin.password;
        loginForm.dispatchEvent(new Event('submit'));
        
        displayMessage(loginMessage, 'Создан временный администратор (логин: admin, пароль: admin123). Пожалуйста, смените пароль!', 'success');
    }
});
    });
});